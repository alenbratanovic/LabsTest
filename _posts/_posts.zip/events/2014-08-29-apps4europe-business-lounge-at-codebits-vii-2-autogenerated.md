---
layout: events-item
category: events
permalink: /events/apps4europe-business-lounge-at-codebits-vii
title: "Apps4Europe business lounge at Codebits VII"
imageurl:
  - ""
tags:
  - apps4europe, business lounge
links:
  - https://codebits.eu/
excerpt:
  - ""
startdate:
  - 10/4/2014
enddate:
  - 
datenotconfirmed:
  - ""
starttime:
  - ""
streetaddress:
  - ""
city:
  - ""
country:
  - ""
europeanaevent:
  - ""
featured:
  - ""
---


