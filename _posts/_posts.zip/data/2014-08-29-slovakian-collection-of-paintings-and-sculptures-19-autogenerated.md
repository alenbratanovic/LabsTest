---
layout: data-item
category: data
title: "Slovakian collection of paintings and sculptures"
permalink: /data/slovakian-collection-of-paintings-and-sculptures
provider: Slovak National Gallery
description: A collection of more than 1,900 sculptures, wooden engravings and paintings  from Slovakia
contact: zlatica.adamciakova@sng.sk
portal: http://europeana.eu/portal/search.html?query=europeana_collectionName%3A07101*&rows=24
console: http://labs.europeana.eu/api/console/?function=search&query=europeana_collectionName%3A07101*&rows=24
providerurl: http://www.webumenia.sk/web/guest/home
imageurl:
  - "/img/datasets/07101-slovak.jpg"
tags:
  - Art

licenses:
dataset: 7101
copyright: Creative Commons Attribution
copyrighturl: http://creativecommons.org/licenses/by/3.0/
---
