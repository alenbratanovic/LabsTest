---
layout: data-item
category: data
title: "Biblical narratives in art from Bibliothèque Municipale de Lyon"
permalink: /data/biblical-narratives-in-art-from-bibliothque-municipale-de-lyon
provider: Bibliothèque municipale de Lyon
description: More than 5,000 black and white drawings, paintings and sketches of mainly biblical narratives. 
contact: bm@bm-lyon.fr
portal: http://europeana.eu/portal/search.html?rows=24&query=europeana_collectionName%3A15802*
console: http://labs.europeana.eu/api/console/?function=search&query=europeana_collectionName%3A15802*
providerurl: http://sged.bm-lyon.fr/
imageurl:
  - "/img/datasets/15802-lyonbible.jpg"
tags:
  - Paintings

licenses:
dataset: 15802
copyright: Creative Commons Public Domain Mark
copyrighturl: http://creativecommons.org/publicdomain/mark/1.0/
---
