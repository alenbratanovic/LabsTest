---
layout: data-item
category: data
title: "Historic photographs from the Netherlands "
permalink: /data/historic-photographs-from-the-netherlands
provider: Gemeentearchief Gemert-Bakel
description: More than 5,000 historic photographs from the Netherlands covering a variety of subjects. Provided by the Gemeentearchief Gemert-Bakel via Digitale Collectie.
contact: gemeente@gemert-bakel.nl
portal: http://europeana.eu/portal/search.html?query=europeana_collectionName%3A2021628*&rows=24
console: http://labs.europeana.eu/api/console/?function=search&query=europeana_collectionName%3A2021628*&rows=24
providerurl: http://www.gemert-bakel.nl/
imageurl:
  - "/img/datasets/2021628-bakel.jpg"
tags:
  - Photographs

licenses:
dataset: 2021628
copyright: Creative Commons Attribution - Share Alike
copyrighturl: http://creativecommons.org/licenses/by-sa/3.0/
---
