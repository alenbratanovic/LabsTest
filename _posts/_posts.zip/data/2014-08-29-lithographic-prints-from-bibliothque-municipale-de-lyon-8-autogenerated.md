---
layout: data-item
category: data
title: "Lithographic prints from Bibliothèque Municipale de Lyon"
permalink: /data/lithographic-prints-from-bibliothque-municipale-de-lyon
provider: Bibliothèque municipale de Lyon
description: More than 500 very colourful lithographic prints, covering various subjects.
contact: bm@bm-lyon.fr
portal: http://europeana.eu/portal/search.html?query=europeana_collectionName%3A15801*&rows=24
console: http://labs.europeana.eu/api/console/?function=search&query=europeana_collectionName%3A15801*&rows=24
providerurl: http://sged.bm-lyon.fr/
imageurl:
  - "/img/datasets/15801-lyonposters.jpg"
tags:
  - Posters

licenses:
dataset: 15801
copyright: Creative Commons Public Domain Mark
copyrighturl: http://creativecommons.org/publicdomain/mark/1.0/
---
