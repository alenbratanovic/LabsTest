---
layout: data-item
category: data
title: "Paintings of Dutch landscapes and local views"
permalink: /data/paintings-of-dutch-landscapes-and-local-views
provider: Gemeentearchief Zaanstad
description: More than 20 paintings of Dutch landscapes and local views. Provided by the Gemeentearchief Zaanstad via Digitale Collectie.
contact: gemeentearchief@zaanstad.nl
portal: http://europeana.eu/portal/search.html?query=europeana_collectionName%3A2021631*&rows=24
console: http://labs.europeana.eu/api/console/?function=search&query=europeana_collectionName%3A2021631*&rows=24
providerurl: http://zaanstad.pictura-dp.nl/
imageurl:
  - "/img/datasets/2021631-zaanstad.jpg"
tags:
  - Paintings

licenses:
dataset: 2021631
copyright: Creative Commons Attribution
copyrighturl: http://creativecommons.org/licenses/by/3.0/
---
