---
layout: apps-item
category: apps
permalink: /apps/europeana-geo-search
title: "Europeana Geo Search"
imageurl:
  - "/img/apps/Europeana%20Geo%20Search/Europeana%20Geo%20Search.jpg"
  - ""
featured: false
tags:
  - Hackathon Prototype
  - Search
  - Geolocation
links:
  - http://amercader.net/dev/geoeuropeana/
  - https://github.com/amercader/geoeuropeana
contact: 
  name: "Adrià Mercader, independent developer

Georg Petz, Austrian National Library"
---

Europeana Geo Search app for Android: http://pro.europeana.eu/c/document_library/get_file?uuid=2ab26ca0-a4e7-4ea7-87fb-a2828fe2e2eb&groupId=462475

1st Hackathon 2011
