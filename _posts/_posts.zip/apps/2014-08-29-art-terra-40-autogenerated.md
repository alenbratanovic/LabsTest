---
layout: apps-item
category: apps
permalink: /apps/art-terra
title: "Art Terra "
imageurl:
  - "/img/apps/Art%20Terra/art_terra.fw%20(1).png"
featured: false
tags:
  - Hackathon Prototype
  - Geolocation
links:
  - 
contact: 
  name: "Krzysztof Figaj, Szymon Janikowski, Paweł Gilewski"
---

Winner in the category 'Social inclusion' at Hack4Europe '11 - Poland.

A web application which allows end-users to create geo-tags referring to chosen multimedia content (i.e. Europeana images). Those tags can be organised into albums, shared and finally browsed using mobile devices.


