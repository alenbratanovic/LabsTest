---
layout: apps-item
category: apps
permalink: /apps/share-what-you-see
title: "Share What You See"
imageurl:
  - "/img/apps/Share%20What%20You%20See/share_what_you_see.fw.png"
featured: false
tags:
  - Hackathon Prototype
  - Social media
  - CMS plugin
links:
  - 
contact: 
  name: "Mia Ridge and Owen Stephens"
---

Share What you See supports easy blogging of Europeana content via Word Press. Winner in the category 'Audience award´ at Hack4Europe '11 - UK.
