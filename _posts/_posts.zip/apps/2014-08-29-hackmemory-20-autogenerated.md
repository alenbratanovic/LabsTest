---
layout: apps-item
category: apps
permalink: /apps/hackmemory
title: "Hackmemory"
imageurl:
  - "/img/apps/Hackmemory/hackmemory.fw.png"
featured: false
tags:
  - Hackathon Prototype
  - Game
links:
  - 
contact: 
  name: "Bartosz Indycki and Dariusz Walczak"
---

A simple educational application for kids and adults based on well-known memory games.

Users search for two exactly matching pictures and, once found, they can read about the pictures' content. Users can create their own quiz and share it with friends on Twitter, Facebook or Buzz. The quiz content comes from Europeana and is filtered by the quiz creator. Pupils and friends can compete and fight for the best place on the leader board – the fastest friend wins!

Hack4Europe '11 - Poland
