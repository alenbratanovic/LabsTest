---
layout: apps-item
category: apps
permalink: /apps/dismarc
title: "DISMARC"
imageurl:
  - "/img/apps/dismarc/DISMARC.jpg"
  - "/img/apps/dismarc/DISMARC_2.gif"
featured: false
tags:
  - API Implementation
  - Search
links:
  - http://www.dismarc.org/
contact: 
  name: ""
---

DISMARC aggregates music from archives all across Europe and makes it available in their own portal and in Europeana. Through our API, searches in their portal also return results from Europeana.
