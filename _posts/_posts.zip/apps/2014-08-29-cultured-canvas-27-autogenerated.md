---
layout: apps-item
category: apps
permalink: /apps/cultured-canvas
title: "Cultured Canvas "
imageurl:
  - "/img/apps/Cultured%20Canvas/cultured_canvas.fw.png"
featured: false
tags:
  - Hackathon Prototype
  - Social media
links:
  - 
contact: 
  name: "Dom Hodgson and Alistair Macdonald"
---

Winner in the category 'Most innovative app'  at Hack4Europe '11 - UK Cultured Canvas is an easy way to promote culture to a user's Twitter followers.

Based on user's preferences/selected criteria, the prototype generates backgrounds of Europeana content for a user's Twitter account.


