---
layout: apps-item
category: apps
permalink: /apps/europeana-banana
title: "Europeana Banana"
imageurl:
  - "/img/apps/Europeana%20Banana/Europeana%20banana.fw.png"
featured: false
tags:
  - Hackathon Prototype
  - Metadata enrichment
  - Game
links:
  - http://pro.europeana.eu/documents/858566/0216948e-dd4d-4d3a-a615-c0bce861b310
contact: 
  name: "Jaap Blom from Beeld en Geluid and Victor de Boer from VU Amsterdam"
---

Semantic enrichment game developed at Europeana's 1st Hackathon in 2011
