---
layout: apps-item
category: apps
permalink: /apps/wikimedia-batch-upload
title: "Wikimedia Batch Upload"
imageurl:
  - "/img/apps/Wikimedia%20Batch%20Upload/wikimedia_batch_upload.png"
featured: false
tags:
  - Hackathon Prototype
  - Rich media
links:
  - http://commons.wikimedia.org/wiki/Category:Images_from_Europeana
contact: 
  name: "Maarten Zeinstra from Kennisland 

Maarten Dammers, Independent developer"
---

This prototype makes it possible to upload content to Wikimedia Commons from Europeana. The prototype has now been superceeded by the GLAMwiki toolset.

1st Hackathon 2011
