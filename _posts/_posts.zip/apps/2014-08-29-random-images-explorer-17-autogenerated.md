---
layout: apps-item
category: apps
permalink: /apps/random-images-explorer
title: "Random Images Explorer"
imageurl:
  - "/img/apps/Random%20Images%20Explorer/random_images_explorer.fw.png"
featured: false
tags:
  - Hackathon Prototype
  - Search
links:
  - 
contact: 
  name: "Willem Jan Faber from the National Library of the Netherlands

Willem-Jan_Faber@Fe2.nl"
---

Semantic enrichment game. 1st Hackathon 2011.
