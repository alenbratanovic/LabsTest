---
layout: apps-item
category: apps
permalink: /apps/open-pics-app
title: "Open Pics app"
imageurl:
  - "/img/apps/open-pics-app/Open_pics_app.jpg"
  - "/img/apps/open-pics-app/Open_pics_app_2.jpg"
featured: false
tags:
  - API Implementation
  - Mobile
  - Tablet
  - Geolocation
links:
  - https://itunes.apple.com/us/app/openpics/id633423505?mt=8
  - https://github.com/pj4533/OpenPics
contact: 
  name: ""
---

This open source app allows search for images in multiple online collections.

This open source app allows search for images in multiple online collections, such as Europeana, New York Public Library, Library of Congress, California Digital Library, Digital Public Library of America, LIFE Magazine photo archive, National Library of Australia (Trove) and Flickr Commons Project.

The app is designed for both iPad and iPhone and is available in 15+ languages.
