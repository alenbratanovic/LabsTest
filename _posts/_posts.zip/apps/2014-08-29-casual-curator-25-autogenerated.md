---
layout: apps-item
category: apps
permalink: /apps/casual-curator
title: "Casual Curator"
imageurl:
  - "/img/apps/Casual%20Curator/casual_curator.jpg"
featured: false
tags:
  - Hackathon Prototype
  - Curation
  - Mobile
links:
  - 
contact: 
  name: "Mike Stapleton, Systems Simulation Ltd. Mike@ssl.co.uk

Mike Selway, Systems Simulation Ltd. mas@ssl.co.uk

Eoin Kilfeather, Dublin Institute of Technology ekilfeathe@dmc.dit.ie

"
---

Winner in the category 'Social Inclusion' at Hack4Europe '11 - UK. Finalist at the Digital Agenda Assembly, June 2011, Brussels.

Casual Curator gets semantically improved search results from Europeana to aid personal curation for learning and teaching: easily organise, annotate and share culture via an Android touchscreen demonstrator. 


