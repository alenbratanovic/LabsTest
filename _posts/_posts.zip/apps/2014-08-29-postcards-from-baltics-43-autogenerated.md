---
layout: apps-item
category: apps
permalink: /apps/postcards-from-baltics
title: "Postcards from Baltics"
imageurl:
  - "/img/apps/Postcards%20from%20Baltics/baltics.fw.png"
featured: false
tags:
  - Hackathon Prototype
  - Mobile
links:
  - https://docs.google.com/presentation/d/1TPqQu9RNnrRCoVi9e2NZmCDmuYaaWAhYolRp5Dqoqy0/edit#slide=id.p
contact: 
  name: "Aleksejs Buzdins, alex.buzdi@gmail.com,
Dmitrijs Buzdins, buzdin@gmail.com,
Dmitrijs Vrublevskis, d.vrublevskis@gmail.com "
---

Winner in the category 'Greatest commercial potential' at Hack4Europe '12 - Latvia.

An Android-based application for learning and sharing history of Baltic towns. 
