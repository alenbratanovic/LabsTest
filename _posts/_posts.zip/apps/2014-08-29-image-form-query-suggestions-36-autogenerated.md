---
layout: apps-item
category: apps
permalink: /apps/image-form-query-suggestions
title: "Image Form Query Suggestions"
imageurl:
  - "/img/apps/Image%20Form%20Query%20Suggestions/Image_Form_Query_Suggestions.jpg"
featured: false
tags:
  - Hackathon Prototype
  - Search
links:
  - https://github.com/diegoceccarelli/hackathon
contact: 
  name: "Diego Ceccarelli from ISTI CNR and Hugo Huurdeman from Timeless Future"
---

Building on an analysis of user behaviour ,this prototype gives users suggestions related to their intitial search query.

However, rather than presenting those suggestions as text links it mashes up with Dbpedia and Freebase to identify people, topics and places and displays those as thumbnails. The user can then click on these thumbnails to navigate further into the Europeana content.

eTech Hackathon 2011
