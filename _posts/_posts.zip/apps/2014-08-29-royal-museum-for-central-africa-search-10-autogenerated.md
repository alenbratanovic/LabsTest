---
layout: apps-item
category: apps
permalink: /apps/royal-museum-for-central-africa-search
title: "Royal Museum for Central Africa search"
imageurl:
  - "/img/apps/royal-museum-for-central-africa-search/AMCA.jpg"
  - "/img/apps/royal-museum-for-central-africa-search/AMCA_2.jpg"
  - "/img/apps/royal-museum-for-central-africa-search/AMCA_3.jpg"
featured: false
tags:
  - API Implementation
  - Search
links:
  - http://www.africamuseum.be/collections/browsecollections/europeana
contact: 
  name: ""
---

The Royal Museum for Central Africa in Belgium is one of Europeana's content providers. On their Plone powered website, they have made their contributed content searchable using the Europeana API.
