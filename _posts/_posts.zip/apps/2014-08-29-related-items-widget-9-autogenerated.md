---
layout: apps-item
category: apps
permalink: /apps/related-items-widget
title: "Related items widget"
imageurl:
  - "/img/apps/related-items-widget/Related_items_widget.jpg"
featured: false
tags:
  - API Implementation
  - Search
links:
  - http://www.wbc.poznan.pl/dlibra/docmetadata?id=1382&from=pubstats
contact: 
  name: ""
---

The PIONIER Network Digital Libraries Federation have a related items widget that uses the Google Translate API to translate keywords to other languages before sending them to the Europeana API.

This widget will be installed on the individual sites of the member libraries of the PIONIER Network Digital Libraries Federation.
