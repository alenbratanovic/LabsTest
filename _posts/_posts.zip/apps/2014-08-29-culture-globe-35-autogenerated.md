---
layout: apps-item
category: apps
permalink: /apps/culture-globe
title: "Culture Globe"
imageurl:
  - "/img/apps/Culture%20Globe/culture_globe.jpg"
featured: false
tags:
  - Hackathon Prototype
  - Geolocation
  - 3D
links:
  - http://cultureglobe.de/
  - http://www.youtube.com/watch?v=H_2pOU1FO6k
contact: 
  name: ""
---

eTech Hackathon 2011 winner Culture Globe allows users to navigate through Europeana content on an interactive globe and timeline.

It accomplishes this by using cutting-edge HTML5 and WebGL technology in combination with semantic information from Europeana and Freebase.


