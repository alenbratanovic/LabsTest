---
layout: apps-item
category: apps
permalink: /apps/art4europe
title: "Art4Europe"
imageurl:
  - "/img/apps/Art4Europe/art4europe.jpg"
featured: false
tags:
  - Hackathon Prototype
  - Rich media
  - Mobile
links:
  - http://www.youtube.com/watch?v=C6PEz2d7OLE
  - http://www.youtube.com/watch?v=cPI3hvZN-Hk
contact: 
  name: "Tomasz Grzywalski, , iTraff Technology, tomasz.grzywalski(at)itraff.pl

Jakub Jurkiewicz, iTraff Technology, jakub.jurkiewicz(at)itraff.pl

Jakub Porzuczek, iTraff Technology, jakub.porzuczek(at)itraff.pl

Marcin Szajek, student at the Poznan University of Technology, szajek(at)programa.pl"
---

Winner in the category 'Greatest commercial potential' at Hack4Europe '11 - Poland. Finalist at the Digital Agenda Assembly, June 2011, Brussels

How many times have you been in an art museum without knowing anything about the paintings you were looking at? Imagine you could take a photo of any painting and get the description of the painting in a matter of seconds! And what if you could translate the description to any of the EU languages? And even have it read out loud for you? You can do this all with the Europeana dataset and the Art4Europe project!

