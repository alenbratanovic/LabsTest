---
layout: data-item
category: data
title: Butterflies from the OpenUp! project
permalink: /data/butterflies-from-the-openup-project
provider: Museum für Naturkunde Berlin, GloBIS
description: More than 400 records with images of butterflies and additional scientific information on scanned labels.
contact: info@mfn-berlin.de
portal: http://creativecommons.org/licenses/by-sa/3.0/
console: 11622
providerurl: 11622
imageurl:
  - /img/datasets/11622_Globis.jpg
tags:
  - http://www.europeana.eu/portal/search.html?query=europeana_collectionName%3A11622*&rows=12

licenses:
  - Creative Commons Attribution - Share Alike
---
