---
layout: data-item
category: data
title: Scans of plants and more natural history objects from the OpenUp! project
permalink: /data/scans-of-plants-and-more-natural-history-objects-from-the-openup-project
provider: Natural History Museum, London
description: More than 110,000 scans of plants  mounted on sheets and photographs of other natural history objects, including molluscs.
contact: openup.helpdesk@africamuseum.be
portal: http://creativecommons.org/licenses/by/3.0/
console: 11621
providerurl: 11621
imageurl:
  - /img/datasets/11621_NHM.jpg
tags:
  - http://www.europeana.eu/portal/search.html?query=europeana_collectionName%3A11621*&rows=12

licenses:
  - Creative Commons Attribution
---
