---
layout: data-item
category: data
title: Scans of plants from the OpenUp! project
permalink: /data/scans-of-plants-from-the-openup-project
provider: Institute of Botany of Slovak Academy of Sciences
description: More than 4,000 scans of plants mounted on sheets.
contact: viera.vitekova@savba.sk
portal: http://creativecommons.org/publicdomain/zero/1.0/
console: 11612
providerurl: 11612
imageurl:
  - /img/datasets/11612_Slovak.jpg
tags:
  - http://www.europeana.eu/portal/search.html?query=europeana_collectionName%3A11612*&rows=12

licenses:
  - Creative Commons CC0
---
