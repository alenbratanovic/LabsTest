---
layout: data-item
category: data
title: Portraits from the Austrian National Library
permalink: /data/portraits-from-the-austrian-national-library
provider: Österreichische Nationalbibliothek
description: A collection of more than 150,000 portraits in black / white and colour. In German.
contact: susanne.tremml@onb.ac.at
portal: http://creativecommons.org/publicdomain/mark/1.0/
console: 92062
providerurl: 92062
imageurl:
  - /img/datasets/92062_ONB.jpg
tags:
  - http://www.europeana.eu/portal/search.html?query=europeana_collectionName:92062*&qf=RIGHTS:http://creativecommons.org/publicdomain/mark/1.0/*&rows=12

licenses:
  - Creative Commons Public Domain Mark
---
