---
layout: data-item
category: data
title: Historic events in paintings from Rybinsk State Architectural, Historical and Art Museum
permalink: /data/historic-events-in-paintings-from-rybinsk-state-architectural-historical-and-art-museum
provider: Rybinsk State Architectural, Historical and Art Museum
description: A collection of 712 paintings in colour. Mostly portraits and historic events. 
contact: RMZ@rybmuseum.ru
portal: http://creativecommons.org/publicdomain/mark/1.0/
console: 2023831
providerurl: 2023831
imageurl:
  - /img/datasets/2023831_Rybinsk.jpg
tags:
  - http://www.europeana.eu/portal/search.html?query=europeana_collectionName:2023831*&qf=paint&qf=REUSABILITY:open&rows=24

licenses:
  - Creative Commons Public Domain Mark
---
