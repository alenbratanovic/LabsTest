---
layout: data-item
category: data
title: WWI collection of the Berlin State Library
permalink: /data/wwi-collection-of-the-berlin-state-library
provider: Staatsbibliothek zu Berlin
description: A collection of more than 6,000 documents and images. In German. 
contact: siegmann@eu1914-1918.eu
portal: http://creativecommons.org/publicdomain/mark/1.0/
console: 9200231
providerurl: 9200231
imageurl:
  - /img/datasets/9200231_SBB.jpg
tags:
  - http://www.europeana.eu/portal/search.html?query=europeana_collectionName%3A9200231*&rows=12

licenses:
  - Creative Commons Public Domain Mark
---
