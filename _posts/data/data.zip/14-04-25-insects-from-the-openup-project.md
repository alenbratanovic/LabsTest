---
layout: data-item
category: data
title: Insects from the OpenUp! project
permalink: /data/insects-from-the-openup-project
provider: Zoological Research Museum Koenig
description: Almost 3,000 images of insects with additional scientific information on scanned labels.
contact: info@zfmk.de
portal: http://creativecommons.org/licenses/by/3.0/
console: 11618
providerurl: 11618
imageurl:
  - /img/datasets/11618_CCBY_Bonn.jpg
tags:
  - http://www.europeana.eu/portal/search.html?query=europeana_collectionName:11618*&qf=RIGHTS:http://creativecommons.org/licenses/by/*&rows=12

licenses:
  - Creative Commons Attribution
---
